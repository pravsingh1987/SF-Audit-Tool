# Salesforce Audit Tool v1.2.6

Release date: April 25, 2026

## What's fixed

- `Missing Sharing Keyword` no longer flags pure wrapper/data-holder classes
- Wrapper-like classes such as `*Wrapper`, `*Request`, `*Response`, `*DTO`, `*Payload`, `*Result`, and `*Data*` are skipped when they do not contain executable logic such as SOQL, DML, REST, callouts, or callable/service behavior
- Prior fixes from `v1.2.4` and `v1.2.5` remain included

## Notes

- This release reduces noise for inner and top-level wrapper classes whose effective execution context is inherited from the surrounding Apex flow
