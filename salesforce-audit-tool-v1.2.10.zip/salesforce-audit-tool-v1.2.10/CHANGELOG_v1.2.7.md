# Salesforce Audit Tool v1.2.7

Release date: April 25, 2026

## What's fixed

- Reduced duplicate `Unsafe HTML - innerHTML Assignment` reporting by deduplicating repeated `innerHTML` writes within the same LWC method
- Downgraded trusted admin/legal-content style `innerHTML` rendering patterns from `Critical` to `Medium`
- Prior fixes from `v1.2.4`, `v1.2.5`, and `v1.2.6` remain included

## Notes

- This release improves LWC report signal quality where metadata-driven legal content is rendered more than once in a single handler
