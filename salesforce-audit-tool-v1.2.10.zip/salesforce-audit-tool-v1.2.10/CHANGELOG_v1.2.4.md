# Salesforce Audit Tool v1.2.4

Release date: April 23, 2026

## What's fixed

- Reduced SOQL injection false positives for:
  - schema-described dynamic object access
  - describe-backed field selection
  - regex allowlisted object names
  - Apex `@isTest` helper code
- Reduced LWC false positives for `Missing Double-Click Prevention` by:
  - skipping non-click handlers such as input/change/field-entry handlers
  - ignoring comments and console statements
  - requiring direct async/network action detection
  - recognizing common loading/processing/disabled guards

## Notes

- This release focuses on audit accuracy improvements and report quality.
- Existing PDF generation behavior is unchanged.
