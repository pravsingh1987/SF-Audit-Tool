# 🚀 Quick Start Guide - Salesforce Code Audit Tool

## ⚡ Super Simple Setup (3 Steps!)

### Step 1: Install Python Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Authenticate to Salesforce (Web Browser)
```bash
sfdx auth:web:login -a myorg
```
**What happens:**
- A browser window opens
- You login to Salesforce (works with MFA!)
- Credentials are securely stored by Salesforce CLI
- No config files needed! ✅

### Step 3: Run the Audit
```bash
python3 salesforce_audit.py
```
**That's it!** The tool will:
- Auto-detect your authenticated org
- Analyze your code
- Generate a comprehensive report in 5-10 minutes

### Optional Step 4: Enable Auto-Update Prompt
If you want users to be prompted to install new releases automatically:

```bash
cp update_config.example.json update_config.json
```

Then edit `update_config.json` and set the hosted `manifest_url` for your release manifest.

---

## 📊 What You Get

**Excel Report** with 6 detailed sheets:
1. **Overview** - Org grade, summary, metrics
2. **Coverage** - Class-by-class test coverage
3. **Issues** - All violations with accurate line numbers
4. **Data Model** - Objects and fields analysis
5. **LWC** - Lightning Web Components analysis

**PDF Executive Summary** (NEW! 📄):
- Professional 5-page leadership report
- Salesforce branding with official logo
- Visual issue breakdown with color coding
- Top priority fixes and action plan
- Perfect for executive presentations
6. **Grading** - Detailed scoring breakdown

**Plus:** Markdown summary for quick review

---

## 💻 Usage Examples

### Run on Auto-Detected Org
```bash
python3 salesforce_audit.py
```

### Run on Specific Org
```bash
python3 salesforce_audit.py --sfdx prod
python3 salesforce_audit.py --sfdx uat
```

### Interactive Mode (Select from Available Orgs)
```bash
python3 salesforce_audit.py -i
```

### Custom Output Directory
```bash
python3 salesforce_audit.py --output-dir ./my-audit-reports
```

### Audit Multiple Orgs
```bash
# Authenticate to all orgs first
sfdx auth:web:login -a prod
sfdx auth:web:login -a uat
sfdx auth:web:login -a dev

# Run audits
python3 salesforce_audit.py --sfdx prod --output-dir ./prod-audit
python3 salesforce_audit.py --sfdx uat --output-dir ./uat-audit
python3 salesforce_audit.py --sfdx dev --output-dir ./dev-audit
```

---

## 🔐 Managing Multiple Orgs

### Authenticate New Org
```bash
sfdx auth:web:login -a myorg-name
```

### List Authenticated Orgs
```bash
sfdx force:org:list
```

### Set Default Org
```bash
sfdx config:set defaultusername=myorg-name
```

### Remove Org Authentication
```bash
sfdx auth:logout -u myorg-name
```

---

## ⏱️ Expected Runtime

| Org Size | Runtime |
|----------|---------|
| Small (< 100 classes) | 2-5 minutes |
| Medium (100-500 classes) | 5-10 minutes |
| Large (500+ classes) | 10-15 minutes |

---

## 🆘 Troubleshooting

### "No authenticated orgs found"
**Solution:** Run `sfdx auth:web:login -a myorg` first

### "SFDX CLI not found"
**Solution:** Install Salesforce CLI:
- **macOS:** `brew install sfdx-cli`
- **Windows:** Download from https://developer.salesforce.com/tools/sfdxcli
- **Linux:** `npm install -g sfdx-cli`

### "Session expired"
**Solution:** Re-authenticate:
```bash
sfdx auth:web:login -a myorg
```

### Need Help?
- Check `TROUBLESHOOTING.md` for comprehensive help
- Run interactive mode: `python3 salesforce_audit.py -i`

---

## 📖 Additional Documentation

- **README.md** - Complete documentation
- **TROUBLESHOOTING.md** - Detailed problem solving
- **FILE_REFERENCE_TABLE.md** - Index of all files

---

## 🎯 What Gets Analyzed

✅ **Test Coverage** - Org-wide and class-level (targets 75%+)  
✅ **Governor Limits** - SOQL/DML in loops, indirect violations  
✅ **Security** - CRUD violations, SOQL injection, XSS  
✅ **Performance** - Non-restrictive queries, inefficient patterns  
✅ **Best Practices** - Code quality, maintainability  
✅ **Lightning Web Components** - Security and best practices  

---

## 🎉 That's It!

**No config files. No credential helpers. Just authenticate and run!**

```bash
# The complete workflow:
pip install -r requirements.txt
sfdx auth:web:login -a myorg
python3 salesforce_audit.py

# View your report:
cd audit_reports
open *.xlsx
```

**Happy auditing!** 🚀