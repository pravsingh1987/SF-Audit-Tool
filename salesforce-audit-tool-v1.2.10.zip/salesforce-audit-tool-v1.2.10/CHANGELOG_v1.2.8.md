# Salesforce Audit Tool v1.2.8

## Report Enhancements

- Added two new columns to the `Detailed Audit` sheet:
  - `Architect/Dev Remarks`
  - `Fix Status` with dropdown values: `Fixed`, `In Progress`, `Not Started`, and `False Positive`
- Extended the `Criticality` dropdown in `Detailed Audit` to include `False Positive`
- Added `False Positive` row shading in the `Detailed Audit` sheet for easier review
- Enhanced the `Metadata Snapshot` sheet:
  - `Test Coverage (%)` now highlights in red when coverage is below 75%
  - `Test Coverage (%)` now highlights in dark green when coverage is above 75%
  - Styled `Org Statistics` and `Issue Summary` as section headers with improved fill formatting

## Notes

- Dynamic grading continues to auto-calculate from the `Criticality` column.
- `False Positive` entries are excluded from issue totals because grading only counts `Critical`, `High`, `Medium`, and `Low`.
