# Salesforce Audit Tool v1.2.9

## Workbook and Grading Updates

- Moved `Grading Calculator` to the 3rd worksheet position
- Linked `Metadata Snapshot -> Test Coverage (%)` to `Grading Calculator` instead of using a static value
- Added `Org Domain Name` to `Metadata Snapshot`
- Added `Architect/Dev Remarks` and `Fix Status` columns to `Detailed Audit`
- Added `False Positive` support in `Criticality` and `Fix Status`
- Added a `Why This Grade?` explainer section to the `Grading Calculator` sheet
- Fixed `Grade Rationale` and `Next Better Grade Blocked By` formula parse errors

## Grading Behavior

- Updated grading thresholds to the latest agreed scale
- Normalized manual coverage testing so both `80` and `80%` work in the calculator
- Loop-based grading now ignores rows marked `False Positive` in either `Criticality` or `Fix Status`
- Added workbook instructions explaining how to waive loop grading for approved false positives
