# Salesforce Audit Tool v1.2.5

Release date: April 23, 2026

## What's fixed

- Aligned `Non-Restrictive Query` severity with the Rules Reference:
  - actual findings now report as `High`
  - Rules Reference remains `High`
- Adjusted `Test Quality` reporting for Apex test classes:
  - any test-class issue that would have been reported as `Critical` is now capped at `High`
  - all other severities remain unchanged

## Notes

- This release focuses on consistency between rule documentation and generated report output.
- Prior false-positive fixes from `v1.2.4` remain included.
