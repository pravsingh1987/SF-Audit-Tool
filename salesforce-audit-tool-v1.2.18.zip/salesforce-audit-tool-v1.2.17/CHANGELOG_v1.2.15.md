# Changelog — v1.2.15

**Release Date:** 2026-05-05

---

## What's New

### Org Health Check — Live Data via Salesforce API (Major Upgrade)

The "Org Health Check" sheet in the audit report has been completely re-engineered.
Instead of parsing `SecuritySettings` XML metadata and approximating values, the tool
now queries **`SecurityHealthCheckRisks`** directly from the Salesforce Tooling API —
the exact same data source that powers **Setup > Security > Health Check** in the UI.

#### Benefits
| Before (v1.2.14)                          | After (v1.2.15)                                 |
|-------------------------------------------|-------------------------------------------------|
| XML metadata parsing (approximate)        | Live Tooling API — mirrors the Salesforce UI exactly |
| ~30 static checks                         | All checks returned by your org (44+ in typical orgs) |
| Many "Unknown" values                     | Real `OrgValue` & `StandardValue` strings        |
| Required `sf CLI` retrieve (slow, ~90s)   | Fast single API call (<5 s)                     |
| Missed Informational / SAML / Admin checks| Full coverage inc. Guest Access, Admin%, PII    |

#### New check groups now included
- **Guest User Access** — objects with Guest User read/edit access
- **Admin Users** — % of active users with System Administrator profile
- **User PII Settings** — permission to view record names in lookup fields
- **External Client Apps** — consumer secret exposure via Metadata API

---

## Bug Fixes

### Fix URLs corrected (all 5 user-reported issues resolved)
| Group                          | Old URL (broken)                                  | New URL (correct)                                   |
|-------------------------------|---------------------------------------------------|-----------------------------------------------------|
| Password Policies              | `.../PasswordPolicies/home`                       | `.../SecurityPolicies/home`                         |
| Login Access Policies          | `.../LoginAccessPolicies/home`                    | `.../SecurityPolicies/home`                         |
| Identity / MFA                 | `.../TwoFactor/home`                              | `.../IdentityVerification/home`                     |
| Session Settings               | `.../SessionSettings/home`                        | `.../SecuritySession/home`                          |
| File Upload & Download Security| `.../FileUploadAndDownloadSecurity/home`          | `.../FileTypeSetting/home`                          |
| Remote Site Settings           | `.../SecurityRemoteSiteSettings/home`             | `.../SecurityRemoteProxy/home`                      |

Fix URLs are now **derived dynamically** from the org's instance URL
(`instance_url.replace('.salesforce.com', '.salesforce-setup.com')`), so they
work correctly for any org — production, sandbox, or scratch.

### Your Value = Standard Value when Compliant (2 user-reported issues resolved)
- **Remote Site Settings**: when the org has no remote sites with "Disable Protocol
  Security" selected, `Your Value` and `Standard Value` both now show
  `"No remote sites with the Disable Protocol Security option selected"`.
- **Number of security risk file types with Hybrid behavior**: when count is 0,
  `Your Value` and `Standard Value` both now show
  `"0 security risk file types with Hybrid behavior"`.

### Informational risk level added to report styling
- A new blue colour theme (`Informational`) is applied to the Risk Level column
  for items categorised as informational by Salesforce (Admin%, Guest Access, etc.).

---

## Fallback Behaviour

If the `SecurityHealthCheckRisks` Tooling API is unavailable (older API version,
restricted permissions), the tool automatically falls back to the previous
`SecuritySettings` XML metadata + individual REST/Tooling API queries approach.

---

## Files Changed
- `org_health_checker.py` — complete rewrite: Tooling API primary + XML fallback
- `report_generator.py` — added `Informational` risk level colour palette
- `tool_version.json` — bumped to `1.2.15`
- `latest-release.json` — updated download URL to `salesforce-audit-tool-v1.2.15.zip`

---

## Carried Forward from v1.2.14
- Org Security Health Check sheet in the Excel report
- All v1.2.13 fixes (DML detection for dotted-notation targets)
- All v1.2.12 fixes (severity corrections, deduplication, line-number accuracy)
