"""
Org Health Checker Module

Retrieves health check data directly from the Salesforce SecurityHealthCheckRisks
Tooling API object — the same engine that powers Setup > Security > Health Check.

Falls back to XML metadata parsing when the Tooling API is unavailable (e.g. older
API versions or permission restrictions).
"""

import logging
import os
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import date
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class HealthCheckItem:
    risk_level: str       # High | Medium | Low | Informational
    status: str           # Compliant | Critical | Warning | Unknown
    setting: str          # Human-readable setting name
    group: str            # Setting group (e.g. "Session Settings")
    your_value: str       # Actual value found in org
    standard_value: str   # Recommended/expected value
    fix_path: str         # Setup navigation path (breadcrumb)
    fix_url: str          # Direct Setup URL
    details: str = ""     # Optional extra context


# ---------------------------------------------------------------------------
# Group → (display name, breadcrumb path, lightning setup URL suffix)
# ---------------------------------------------------------------------------
_GROUP_MAP: Dict[str, tuple] = {
    'SessionSettings':              (
        'Session Settings',
        'Setup > Security > Session Settings',
        'lightning/setup/SecuritySession/home',
    ),
    'PasswordPolicies':             (
        'Password Policies',
        'Setup > Security > Password Policies',
        'lightning/setup/SecurityPolicies/home',
    ),
    'LoginAccessPolicies':          (
        'Login Access Policies',
        'Setup > Security > Login Access Policies',
        'lightning/setup/SecurityPolicies/home',
    ),
    'Identity':                     (
        'Identity',
        'Setup > Security > Identity Verification',
        'lightning/setup/IdentityVerification/home',
    ),
    'FileUploadAndDownloadSecurity': (
        'File Upload And Download Security',
        'Setup > Security > File Upload and Download Security',
        'lightning/setup/FileTypeSetting/home',
    ),
    'RemoteSiteSettings':           (
        'Remote Site Settings',
        'Setup > Security > Remote Site Settings',
        'lightning/setup/SecurityRemoteProxy/home',
    ),
    'CertificateAndKeyManagement':  (
        'Certificate and Key Management',
        'Setup > Security > Certificate and Key Management',
        'lightning/setup/CertificateAndKeyManagement/home',
    ),
    'SharingSettings':              (
        'Sharing Settings',
        'Setup > Security > Sharing Settings',
        'lightning/setup/SecuritySharingRules/home',
    ),
    'NetworkSecurity':              (
        'Network Security',
        'Setup > Security > Network Access',
        'lightning/setup/NetworkAccess/home',
    ),
    'GuestUserAccess':              (
        'Guest User Access',
        'Setup > Security > Guest Access',
        'lightning/setup/GuestAccess/home',
    ),
    'AdminUsers':                   (
        'Admin Users',
        'Setup > Users > Manage Users',
        'lightning/setup/ManageUsers/home',
    ),
    'UserPIISettings':              (
        'User PII Settings',
        'Setup > Security > Data Protection and Privacy',
        'lightning/setup/DataProtectionAndPrivacy/home',
    ),
    'ExternalClientApps':           (
        'External Client Apps',
        'Setup > Apps > Connected Apps > External Client Apps',
        'lightning/setup/ConnectedApplication/home',
    ),
    # Supplementary group — pulled from SecuritySettings XML (not in Tooling API)
    'BrowserSecurityHeaders':       (
        'Browser & Session Security',
        'Setup > Security > Session Settings > Browser Security',
        'lightning/setup/SecuritySession/home',
    ),
}

# API enum → display string
_RISK_CATEGORY_MAP = {
    'HIGH_RISK':     'High',
    'MEDIUM_RISK':   'Medium',
    'LOW_RISK':      'Low',
    'INFORMATIONAL': 'Informational',
}

_RISK_TYPE_STATUS_MAP = {
    'MEETS_STANDARD': 'Compliant',
    'HIGH_RISK':      'Critical',
    'MEDIUM_RISK':    'Warning',
    'LOW_RISK':       'Warning',
}

# Sort helpers
_RISK_ORDER   = {'High': 0, 'Medium': 1, 'Low': 2, 'Informational': 3}
_STATUS_ORDER = {'Critical': 0, 'Warning': 1, 'Compliant': 2, 'Unknown': 3}


class OrgHealthChecker:
    """
    Retrieves and evaluates Salesforce org security settings.

    Primary path  : SecurityHealthCheckRisks Tooling API — the same live data
                    that Salesforce displays in Setup > Security > Health Check.
    Fallback path : SecuritySettings XML metadata + individual API queries.
    """

    def __init__(self, sf_client, org_alias: str, instance_url: str = ""):
        self.sf = sf_client
        self.org_alias = org_alias
        self.instance_url = instance_url.rstrip("/")
        # Setup pages use .salesforce-setup.com instead of .salesforce.com
        self._setup_base = self.instance_url.replace(
            '.salesforce.com', '.salesforce-setup.com'
        )

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run_health_check(self) -> List[HealthCheckItem]:
        """
        Return sorted HealthCheckItems.

        Primary path  : SecurityHealthCheckRisks Tooling API (mirrors Salesforce UI).
        Supplementary : SecuritySettings XML — adds COOP, COEP, CSP, POST-sessions,
                        and browser-caching checks not covered by the Tooling API.
        Fallback path : Full XML-based checks when the Tooling API is unavailable.
        """
        # Always retrieve the SecuritySettings XML; it feeds supplementary checks
        # in the primary path AND is the sole source in the fallback path.
        sec = self._retrieve_security_settings()

        items = self._retrieve_via_tooling_api()
        if items:
            logger.info(
                "Health check sourced from SecurityHealthCheckRisks API (%d items).",
                len(items),
            )
            # Append supplementary checks that the Tooling API doesn't cover
            items.extend(self._check_browser_security_headers(sec))
            return sorted(
                items,
                key=lambda i: (
                    _RISK_ORDER.get(i.risk_level, 99),
                    _STATUS_ORDER.get(i.status, 99),
                ),
            )

        logger.info("SecurityHealthCheckRisks API unavailable — using XML fallback.")
        fallback: List[HealthCheckItem] = []
        fallback.extend(self._check_session_settings(sec))
        fallback.extend(self._check_password_policies(sec))
        fallback.extend(self._check_login_access_policies(sec))
        fallback.extend(self._check_certificates())
        fallback.extend(self._check_sharing_settings())
        fallback.extend(self._check_network_security(sec))
        fallback.extend(self._check_remote_sites())
        fallback.extend(self._check_file_security())
        fallback.extend(self._check_mfa())
        fallback.extend(self._check_browser_security_headers(sec))
        return fallback

    # ------------------------------------------------------------------
    # PRIMARY: Tooling API — SecurityHealthCheckRisks
    # ------------------------------------------------------------------

    def _tooling_query(self, soql: str) -> List[dict]:
        """Execute SOQL against the Salesforce Tooling API."""
        import urllib.parse
        encoded = urllib.parse.quote(soql)
        url = f"{self.sf.base_url}tooling/query/?q={encoded}"
        resp = self.sf._call_salesforce("GET", url)
        return resp.json().get("records", [])

    def _retrieve_via_tooling_api(self) -> List[HealthCheckItem]:
        """
        Query SecurityHealthCheckRisks — the live data behind
        Setup > Security > Health Check. Returns [] if the object is
        unavailable so the caller can fall back gracefully.
        """
        try:
            records = self._tooling_query(
                "SELECT RiskType, Setting, SettingGroup, OrgValue, StandardValue, "
                "SettingRiskCategory FROM SecurityHealthCheckRisks LIMIT 200"
            )
            if not records:
                logger.warning("SecurityHealthCheckRisks returned 0 records.")
                return []

            items: List[HealthCheckItem] = []
            for r in records:
                group_key = r.get('SettingGroup', '')
                group_info = _GROUP_MAP.get(group_key)

                if group_info:
                    group_display, fix_path, url_suffix = group_info
                else:
                    group_display = group_key
                    fix_path = f"Setup > {group_key}"
                    url_suffix = 'lightning/setup/SecurityHealthCheck/home'

                fix_url = (
                    f"{self._setup_base}/{url_suffix}"
                    if self._setup_base else url_suffix
                )

                risk_category = r.get('SettingRiskCategory', 'HIGH_RISK')
                risk_type     = r.get('RiskType', 'HIGH_RISK')

                items.append(HealthCheckItem(
                    risk_level     = _RISK_CATEGORY_MAP.get(risk_category, 'High'),
                    status         = _RISK_TYPE_STATUS_MAP.get(risk_type, 'Unknown'),
                    setting        = r.get('Setting', ''),
                    group          = group_display,
                    your_value     = r.get('OrgValue', '') or '',
                    standard_value = r.get('StandardValue', '') or '',
                    fix_path       = fix_path,
                    fix_url        = fix_url,
                ))
            return items

        except Exception as exc:
            logger.warning("SecurityHealthCheckRisks API error: %s", exc)
            return []

    # ------------------------------------------------------------------
    # FALLBACK: SecuritySettings XML metadata
    # ------------------------------------------------------------------

    def _retrieve_security_settings(self) -> Dict[str, Any]:
        """
        Pull SecuritySettings metadata via the sf CLI and flatten to a
        dot-notation dict.  Returns {} on any failure.
        """
        if not self.org_alias:
            logger.warning("No org alias — SecuritySettings will show as Unknown.")
            return {}

        project_dir = tempfile.mkdtemp(prefix="sf_health_check_")
        try:
            import json as _json
            _json.dump(
                {
                    "packageDirectories": [{"path": "force-app", "default": True}],
                    "name": "temp-health-check",
                    "namespace": "",
                    "sourceApiVersion": "59.0",
                },
                open(os.path.join(project_dir, "sfdx-project.json"), "w"),
            )
            os.makedirs(os.path.join(project_dir, "force-app"), exist_ok=True)

            try:
                subprocess.run(
                    [
                        "sf", "project", "retrieve", "start",
                        "--metadata", "Settings:Security",
                        "--target-org", self.org_alias,
                        "--json",
                    ],
                    capture_output=True, text=True, timeout=180,
                    cwd=project_dir,
                )
            except subprocess.TimeoutExpired:
                logger.warning(
                    "sf CLI timed out retrieving SecuritySettings — checking partial output."
                )

            for dirpath, _, filenames in os.walk(project_dir):
                for fname in filenames:
                    if fname.endswith(".settings-meta.xml"):
                        fpath = os.path.join(dirpath, fname)
                        try:
                            tree = ET.parse(fpath)
                            return self._flatten_xml(tree.getroot())
                        except ET.ParseError as pe:
                            logger.warning("XML parse error in %s: %s", fpath, pe)
        except FileNotFoundError:
            logger.warning("sf CLI not found; SecuritySettings will show as Unknown.")
        except Exception as exc:
            logger.warning("Unexpected error retrieving SecuritySettings: %s", exc)
        finally:
            import shutil as _shutil
            _shutil.rmtree(project_dir, ignore_errors=True)
        return {}

    @staticmethod
    def _flatten_xml(root: ET.Element, prefix: str = "") -> Dict[str, str]:
        """Recursively flatten XML into a dot-notation dict."""
        out: Dict[str, str] = {}
        for child in root:
            tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            key = f"{prefix}.{tag}" if prefix else tag
            if len(child) == 0:
                out[key] = (child.text or "").strip()
            else:
                out.update(OrgHealthChecker._flatten_xml(child, key))
        return out

    # ------------------------------------------------------------------
    # Fallback helper factories
    # ------------------------------------------------------------------

    def _item(
        self,
        risk_level: str,
        setting: str,
        group: str,
        your_value: Any,
        standard_value: str,
        compliant: Optional[bool],
        details: str = "",
    ) -> HealthCheckItem:
        if compliant is None:
            status = "Unknown"
        elif compliant:
            status = "Compliant"
        else:
            status = "Critical"

        group_info = _GROUP_MAP.get(group)
        if group_info:
            _, fix_path, url_suffix = group_info
        else:
            fix_path   = f"Setup > {group}"
            url_suffix = ""

        fix_url = (
            f"{self._setup_base}/{url_suffix}"
            if self._setup_base and url_suffix
            else url_suffix
        )

        return HealthCheckItem(
            risk_level     = risk_level,
            status         = status,
            setting        = setting,
            group          = group,
            your_value     = str(your_value) if your_value not in (None, "") else "Unknown",
            standard_value = standard_value,
            fix_path       = fix_path,
            fix_url        = fix_url,
            details        = details,
        )

    def _bool_from(self, settings: Dict, *keys) -> Optional[bool]:
        for k in keys:
            v = settings.get(k)
            if v is not None:
                return str(v).strip().lower() == "true"
        return None

    def _display_bool(self, v: Optional[bool]) -> str:
        if v is True:
            return "Enabled"
        if v is False:
            return "Disabled"
        return "Unknown"

    # ------------------------------------------------------------------
    # Fallback: Session Settings
    # ------------------------------------------------------------------

    def _check_session_settings(self, s: Dict) -> List[HealthCheckItem]:
        g = "SessionSettings"
        items = []

        def add(risk, setting, keys, expected_true=True, standard="Enabled", details=""):
            key_list = [keys] if isinstance(keys, str) else keys
            v = self._bool_from(s, *key_list)
            compliant = (None if v is None else (v is True if expected_true else v is False))
            items.append(self._item(risk, setting, g, self._display_bool(v), standard, compliant, details))

        add("Medium", "Enforce login IP ranges on every request",
            "sessionSettings.enforceIpRangesEveryRequest")
        v = self._bool_from(s, "sessionSettings.forceLogoutOnSessionTimeout")
        items.append(self._item("Medium",
            "Terminate all of a user's sessions when password is reset",
            g, self._display_bool(v), "Enabled", v is True if v is not None else None))
        add("Medium", "Force relogin after Login-As-User",
            ["sessionSettings.forceRelogin", "sessionSettings.forceReloginAfterLoginAs"])
        add("Medium", "Enable Content Security Policy protection for email templates",
            "sessionSettings.enableCSPOnEmail")
        add("Medium", "Enable Content Sniffing protection",
            "sessionSettings.enableContentSniffingProtection")
        add("Low", "Require identity verification for email address changes",
            ["sessionSettings.identityConfirmationOnEmailChange",
             "sessionSettings.requireEmailConfirmForEmailChange"])
        add("Low", "Force logout on session timeout", "sessionSettings.forceLogoutOnSessionTimeout")
        add("Low", "Require identity verification during MFA registration",
            ["sessionSettings.identityConfirmationOnTwoFactorRegistrationEnabled",
             "sessionSettings.requireVerificationForMFARegistration"])

        timeout_raw = s.get("sessionSettings.sessionTimeout", "")
        _timeout_map = {
            "FiveMinutes": "5 minutes", "TenMinutes": "10 minutes",
            "FifteenMinutes": "15 minutes", "TwentyMinutes": "20 minutes",
            "ThirtyMinutes": "30 minutes", "SixtyMinutes": "60 minutes",
            "TwoHours": "2 hours", "FourHours": "4 hours",
            "EightHours": "8 hours", "TwelveHours": "12 hours",
            "TwentyFourHours": "24 hours",
        }
        timeout_compliant_set = {"FiveMinutes", "TenMinutes", "FifteenMinutes", "TwentyMinutes", "ThirtyMinutes"}
        items.append(self._item("Low", "Session Timeout", g,
            _timeout_map.get(timeout_raw, timeout_raw or "Unknown"),
            "15 minutes",
            (timeout_raw in timeout_compliant_set) if timeout_raw else None))

        add("High", "Lock sessions to the domain in which they were first used",
            "sessionSettings.lockSessionsToDomain")
        add("High", "Let users verify their identity by text (SMS)",
            ["sessionSettings.enableSMSIdentity", "sessionSettings.smsEnabled"])
        add("High", "Enable clickjack protection for Setup pages",
            "sessionSettings.enableClickjackSetup")
        add("High", "Enable clickjack protection for non-Setup Salesforce pages",
            ["sessionSettings.enableClickjackNonsetupSFDC",
             "sessionSettings.enableClickjackNonsetup"])

        v = self._bool_from(s, "sessionSettings.enableClickjackNonsetupUser",
                            "sessionSettings.enableClickjackNonsetupHeaders")
        items.append(self._item("High",
            "Enable clickjack protection for customer VF pages with standard headers",
            g, self._display_bool(v), "Enabled", v is True if v is not None else None))

        v = self._bool_from(s, "sessionSettings.enableClickjackNonsetupUserHeaderless",
                            "sessionSettings.enableClickjackNonsetupNoheaders")
        items.append(self._item("High",
            "Enable clickjack protection for customer VF pages with headers disabled",
            g, self._display_bool(v), "Enabled", v is True if v is not None else None))

        add("High", "Enable CSRF protection on GET requests on non-setup pages",
            ["sessionSettings.enableCSRFOnGet", "sessionSettings.enableCsrfNonSetupGet"])
        add("High", "Enable CSRF protection on POST requests on non-setup pages",
            ["sessionSettings.enableCSRFOnPost", "sessionSettings.enableCsrfNonSetupPost"])
        add("High", "Require HttpOnly attribute",
            ["sessionSettings.requireHttpOnly", "sessionSettings.enableHttpOnly"])
        return items

    # ------------------------------------------------------------------
    # Fallback: Password Policies
    # ------------------------------------------------------------------

    def _check_password_policies(self, s: Dict) -> List[HealthCheckItem]:
        g = "PasswordPolicies"
        items = []

        v = self._bool_from(s, "passwordPolicies.minimumPasswordLifetime")
        items.append(self._item("Medium", "Require a minimum 1 day password lifetime",
            g, self._display_bool(v), "Enabled", v is True if v is not None else None))

        expiry_raw = s.get("passwordPolicies.expiration", "")
        _expiry_map = {
            "ThirtyDays": "30 days", "SixtyDays": "60 days", "NinetyDays": "90 days",
            "SixMonths": "180 days", "OneYear": "365 days", "Never": "Never",
        }
        items.append(self._item("Medium", "User passwords expire in", g,
            _expiry_map.get(expiry_raw, expiry_raw or "Unknown"), "30 days",
            (expiry_raw in ("ThirtyDays", "SixtyDays", "NinetyDays")) if expiry_raw else None))

        complexity_raw = s.get("passwordPolicies.complexity", "")
        _complexity_map = {
            "AlphaNumericSpecialCharacters": "Must include alpha, numeric, and special characters",
            "AlphaNumeric": "Must include alpha and numeric",
            "SpecialCharacters": "Must include special characters",
            "Alphabetic": "Alphabetic only", "NoRestriction": "No restriction",
        }
        items.append(self._item("Medium", "Password complexity requirement", g,
            _complexity_map.get(complexity_raw, complexity_raw or "Unknown"),
            "Must include alpha, numeric, and special characters",
            complexity_raw == "AlphaNumericSpecialCharacters" if complexity_raw else None))

        history_raw = s.get("passwordPolicies.historyRestriction", "")
        items.append(self._item("Medium", "Enforce password history", g,
            f"{history_raw} passwords remembered" if history_raw and history_raw.isdigit() and history_raw != "0" else (history_raw or "Unknown"),
            "3 passwords remembered",
            (int(history_raw) >= 3) if (history_raw and history_raw.isdigit()) else None))

        min_len_raw = s.get("passwordPolicies.minimumPasswordLength",
                            s.get("passwordPolicies.minPasswordLength", ""))
        items.append(self._item("Medium", "Minimum password length", g,
            f"{min_len_raw} characters" if min_len_raw and min_len_raw.isdigit() else (min_len_raw or "Unknown"),
            "8 characters",
            (int(min_len_raw) >= 8) if (min_len_raw and min_len_raw.isdigit()) else None))

        v = self._bool_from(s, "passwordPolicies.obscureSecretAnswer")
        items.append(self._item("Low", "Obscure secret answer for password resets",
            g, self._display_bool(v), "Enabled", v is True if v is not None else None))

        q_raw = s.get("passwordPolicies.passwordQuestion",
                      s.get("passwordPolicies.questionRestriction", ""))
        _question_map = {
            "CannotContainPassword": "Cannot contain password",
            "DoesNotConstrainPasswordQuestion": "No restriction",
        }
        items.append(self._item("Low", "Password question requirement", g,
            _question_map.get(q_raw, q_raw or "Unknown"), "Cannot contain password",
            q_raw == "CannotContainPassword" if q_raw else None))

        lockout_raw = s.get("passwordPolicies.lockoutInterval", "")
        _lockout_map = {
            "FifteenMinutes": "15 minutes", "ThirtyMinutes": "30 minutes",
            "SixtyMinutes": "60 minutes", "Forever": "Forever (until admin reset)",
        }
        items.append(self._item("Low", "Lockout effective period", g,
            _lockout_map.get(lockout_raw, lockout_raw or "Unknown"), "30 minutes",
            lockout_raw in ("FifteenMinutes", "ThirtyMinutes") if lockout_raw else None))

        max_attempts_raw = s.get("passwordPolicies.maxLoginAttempts", "")
        _attempts_map = {
            "ThreeAttempts": "3", "FiveAttempts": "5",
            "TenAttempts": "10", "NoLimit": "No limit",
        }
        _attempts_numeric = {"ThreeAttempts": 3, "FiveAttempts": 5, "TenAttempts": 10}
        max_num = _attempts_numeric.get(max_attempts_raw)
        items.append(self._item("High", "Maximum invalid login attempts", g,
            _attempts_map.get(max_attempts_raw, max_attempts_raw or "Unknown"), "3",
            (max_num is not None and max_num <= 3) if max_attempts_raw else None))

        return items

    # ------------------------------------------------------------------
    # Fallback: Login Access Policies
    # ------------------------------------------------------------------

    def _check_login_access_policies(self, s: Dict) -> List[HealthCheckItem]:
        g = "LoginAccessPolicies"
        v = self._bool_from(s,
            "enableAdminLoginAsAnyUser",
            "loginAccessPolicies.allowAllAdminToLogAsUser",
            "loginAccessPolicies.authorizedRepresentativesCanLogInAs",
        )
        compliant = (v is False) if v is not None else None
        return [self._item("Medium", "Administrators Can Log in as Any User",
                           g, self._display_bool(v), "Disabled", compliant)]

    # ------------------------------------------------------------------
    # Fallback: Certificates
    # ------------------------------------------------------------------

    def _check_certificates(self) -> List[HealthCheckItem]:
        g = "CertificateAndKeyManagement"
        today_str = date.today().isoformat()
        try:
            certs = self._tooling_query(
                "SELECT Id, DeveloperName, ExpirationDate FROM Certificate"
            )
            expired = [
                c for c in certs
                if c.get("ExpirationDate") and str(c["ExpirationDate"])[:10] < today_str
            ]
            count = len(expired)
            details = (
                f"{len(certs)} certificate(s) total; {count} expired"
                + (f": {', '.join(c.get('DeveloperName','?') for c in expired[:3])}" if expired else "")
                if certs else "No certificates found"
            )
            return [self._item("High", "Expired Certificate", g, str(count), "0", count == 0, details)]
        except Exception as exc:
            logger.warning("Could not query Certificate via Tooling API: %s", exc)
            return [self._item("High", "Expired Certificate", g, "Unable to retrieve", "0", None, str(exc))]

    # ------------------------------------------------------------------
    # Fallback: Sharing Settings
    # ------------------------------------------------------------------

    def _check_sharing_settings(self) -> List[HealthCheckItem]:
        g = "SharingSettings"
        try:
            result = self.sf.query(
                "SELECT QualifiedApiName, ExternalSharingModel FROM EntityDefinition "
                "WHERE ExternalSharingModel IN ('Read','ReadWrite','ReadWriteTransfer') "
                "AND IsCustomizable = true LIMIT 500"
            )
            records = result.get("records", [])
            count = len(records)
            objects_list = ", ".join(r.get("QualifiedApiName", "?") for r in records[:5])
            details = (
                f"{count} object(s) with public external access: {objects_list}"
                + (" ..." if count > 5 else "")
            ) if count > 0 else "All objects restricted for external access"
            return [self._item("High",
                               "Number of Objects with Default External Access Set to Public",
                               g, str(count), "0", count == 0, details)]
        except Exception as exc:
            logger.warning("Could not query EntityDefinition for sharing: %s", exc)
            return [self._item("High",
                               "Number of Objects with Default External Access Set to Public",
                               g, "Unable to retrieve", "0", None, str(exc))]

    # ------------------------------------------------------------------
    # Fallback: Network Security
    # ------------------------------------------------------------------

    def _check_network_security(self, s: Dict = None) -> List[HealthCheckItem]:
        g = "NetworkSecurity"
        if s:
            network_keys = [k for k in s if k.startswith("networkAccess.")]
            if "networkAccess" in s or network_keys:
                ip_entries = {k.split(".")[1] for k in network_keys if "." in k}
                count = len(ip_entries)
                return [self._item("High", "Number of trusted IP ranges",
                                   g, str(count), "1", count >= 1,
                                   f"{count} trusted IP range(s) in SecuritySettings")]
        for soql in (
            "SELECT IpStartAddress, IpEndAddress FROM NetworkAccess",
            "SELECT IpStartAddress, IpEndAddress FROM TrustedIpRange",
        ):
            try:
                records = self._tooling_query(soql)
                count = len(records)
                return [self._item("High", "Number of trusted IP ranges",
                                   g, str(count), "1", count >= 1,
                                   f"{count} trusted IP range(s) configured")]
            except Exception:
                continue
        return [self._item("High", "Number of trusted IP ranges",
                           g, "Unable to retrieve", "1", None,
                           "NetworkAccess not queryable — verify manually in Setup > Network Access")]

    # ------------------------------------------------------------------
    # Fallback: Remote Site Settings
    # ------------------------------------------------------------------

    def _check_remote_sites(self) -> List[HealthCheckItem]:
        g = "RemoteSiteSettings"
        std = "No remote sites with the Disable Protocol Security option selected"
        try:
            all_sites = self._tooling_query("SELECT Id, EndpointUrl FROM RemoteProxy")
            total = len(all_sites)
            if total == 0:
                return [self._item("Low", "Remote Site Settings", g, std, std, True,
                                   "No remote sites configured")]
            # Cannot verify DisableProtocolSecurity field — report as Unknown
            return [self._item("Low", "Remote Site Settings", g,
                               f"{total} remote site(s) — protocol security flag not verifiable via API",
                               std, None,
                               "Verify each site's 'Disable Protocol Security' option manually in Setup")]
        except Exception as exc:
            logger.warning("Could not query RemoteProxy via Tooling API: %s", exc)
            return [self._item("Low", "Remote Site Settings", g,
                               "Unable to retrieve", std, None, str(exc))]

    # ------------------------------------------------------------------
    # Fallback: File Upload and Download Security
    # ------------------------------------------------------------------

    def _check_file_security(self) -> List[HealthCheckItem]:
        g = "FileUploadAndDownloadSecurity"
        std = "0 security risk file types with Hybrid behavior"
        for soql in (
            "SELECT Count() FROM FileType WHERE BehaviorOnExecution = 'Hybrid'",
            "SELECT Count() FROM FileSecurityBehavior WHERE BehaviorOnExecution = 'Hybrid'",
        ):
            try:
                result = self.sf.query(soql)
                count = result.get("totalSize", 0)
                your_value = std if count == 0 else f"{count} security risk file types with Hybrid behavior"
                return [self._item("High",
                                   "Number of security risk file types with Hybrid behavior",
                                   g, your_value, std, count == 0)]
            except Exception:
                continue
        try:
            records = self._tooling_query(
                "SELECT Id, Extension FROM FileType WHERE SecurityBehavior = 'Hybrid'"
            )
            count = len(records)
            your_value = std if count == 0 else f"{count} security risk file types with Hybrid behavior"
            return [self._item("High",
                               "Number of security risk file types with Hybrid behavior",
                               g, your_value, std, count == 0)]
        except Exception:
            pass
        return [self._item("High",
                           "Number of security risk file types with Hybrid behavior",
                           g, "Unable to retrieve", std, None)]

    # ------------------------------------------------------------------
    # Supplementary: Browser & Session Security Headers (XML-sourced)
    # These settings are not covered by the SecurityHealthCheckRisks API.
    # ------------------------------------------------------------------

    def _check_browser_security_headers(self, s: Dict) -> List[HealthCheckItem]:
        """
        Checks pulled from SecuritySettings XML that are NOT included in the
        Salesforce SecurityHealthCheckRisks Tooling API.

        Covers:
          - Cross-Origin Opener Policy (COOP)
          - Cross-Origin Embedder Policy (COEP)
          - Apply CSP directives for less common browsers
          - Override Restriction on Email Templates in Classic / IE  (manual)
          - Use POST requests for cross-domain sessions
          - Enable secure and persistent browser caching
        """
        g = 'BrowserSecurityHeaders'
        items: List[HealthCheckItem] = []

        def add(risk, setting, keys, standard="Enabled", expected_true=True, details=""):
            key_list = [keys] if isinstance(keys, str) else list(keys)
            v = self._bool_from(s, *key_list)
            compliant = (None if v is None
                         else (v is True if expected_true else v is False))
            items.append(self._item(risk, setting, g,
                                    self._display_bool(v), standard, compliant, details))

        # 1. Cross-Origin Opener Policy (COOP)
        add(
            "Medium",
            "Cross-Origin Opener Policy (COOP)",
            ["sessionSettings.enableCoopHeader", "enableCoopHeader"],
            standard="Enabled",
            details=(
                "When enabled, Salesforce sets the Cross-Origin-Opener-Policy response "
                "header to 'same-origin', isolating the browsing context and preventing "
                "cross-origin window attacks. Recommended: Enabled."
            ),
        )

        # 2. Cross-Origin Embedder Policy (COEP)
        add(
            "Medium",
            "Cross-Origin Embedder Policy (COEP)",
            ["sessionSettings.enableCoepHeader", "enableCoepHeader"],
            standard="Enabled",
            details=(
                "Sets the Cross-Origin-Embedder-Policy header to 'require-corp', "
                "ensuring only explicitly permitted cross-origin resources are loaded. "
                "Required for enabling high-resolution timers and SharedArrayBuffer. "
                "Recommended: Enabled."
            ),
        )

        # 3. Apply CSP directives for less common browsers
        add(
            "Medium",
            "Apply CSP directives for less common browsers",
            ["sessionSettings.sendCspForUncommonClients", "sendCspForUncommonClients"],
            standard="Enabled",
            details=(
                "Extends Content Security Policy (CSP) header delivery to browsers "
                "that don't fully support the CSP specification. Increases protection "
                "against XSS attacks across all user agents. Recommended: Enabled."
            ),
        )

        # 4. Override Restriction on Email Templates in Salesforce Classic / IE
        # This setting is not exposed via the SecuritySettings Metadata API.
        items.append(HealthCheckItem(
            risk_level     = "Low",
            status         = "Unknown",
            setting        = "Override Restriction on Accessing Email Templates in Salesforce Classic (IE)",
            group          = "Browser & Session Security",
            your_value     = "Verify manually",
            standard_value = "Disabled (leave restriction ON for security)",
            fix_path       = "Setup > Security > Session Settings > Browser Security",
            fix_url        = (
                f"{self._setup_base}/lightning/setup/SecuritySession/home"
                if self._setup_base
                else "lightning/setup/SecuritySession/home"
            ),
            details        = (
                "This Classic/IE-specific setting is not exposed via the Salesforce "
                "Metadata API. Navigate to Setup > Session Settings > Browser Security "
                "to verify. Leaving the restriction ON (setting disabled) is recommended "
                "as Internet Explorer is end-of-life."
            ),
        ))

        # 5. Use POST requests for cross-domain sessions
        add(
            "Medium",
            "Use POST requests for cross-domain sessions",
            "sessionSettings.enablePostForSessions",
            standard="Enabled",
            details=(
                "Forces session token transmission via HTTP POST instead of URL query "
                "parameters when crossing domains, preventing session tokens from "
                "appearing in server logs or browser history. Recommended: Enabled."
            ),
        )

        # 6. Enable secure and persistent browser caching to improve performance
        add(
            "Low",
            "Enable secure and persistent browser caching to improve performance",
            "sessionSettings.enableCacheAndAutocomplete",
            standard="Enabled",
            details=(
                "Enables persistent browser caching of static assets with secure "
                "cache-control headers. Improves page load performance while maintaining "
                "security. Recommended: Enabled."
            ),
        )

        return items

    # ------------------------------------------------------------------
    # Fallback: MFA / Identity
    # ------------------------------------------------------------------

    def _check_mfa(self) -> List[HealthCheckItem]:
        g = "Identity"
        try:
            records = self._tooling_query(
                "SELECT IsRequiredForAllUsers FROM MFAEnforcement LIMIT 1"
            )
            if records:
                v = records[0].get("IsRequiredForAllUsers", False)
                return [self._item("High", "MFA Enabled", g,
                                   "Enabled" if v else "Disabled", "Enabled", bool(v))]
        except Exception:
            pass
        for soql in (
            "SELECT IsMfaRequired FROM Organization LIMIT 1",
            "SELECT IsMfaDirectUiLoginRequired FROM Organization LIMIT 1",
        ):
            try:
                result = self.sf.query(soql)
                records = result.get("records", [])
                if records:
                    field = [k for k in records[0] if k != "attributes"][0]
                    v = records[0].get(field, False)
                    return [self._item("High", "MFA Enabled", g,
                                       "Enabled" if v else "Disabled", "Enabled", bool(v))]
            except Exception:
                continue
        return [self._item("High", "MFA Enabled", g,
                           "Unable to retrieve", "Enabled", None,
                           "Verify manually in Setup > Identity Verification")]
