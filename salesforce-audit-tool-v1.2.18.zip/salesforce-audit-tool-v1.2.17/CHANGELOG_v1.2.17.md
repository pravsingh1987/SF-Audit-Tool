# Changelog — v1.2.17

**Release Date:** 2026-05-18

---

## Fixes — Loop Analyzer False Positives

This release fixes four Apex loop-analyzer false positives, one CRUD/FLS
reporting false positive, and tunes several noisy Apex Guru-style heuristics:

1. `SOQL in Loop` was incorrectly reported for queries that appear after a
   same-line braceless loop.
2. `DML in Loop` was incorrectly reported when commented-out braces inside a
   loop confused the brace counter and extended the detected loop scope.
3. `Indirect SOQL in Loop` / `Indirect DML in Loop` were incorrectly reported
   when control-flow statements such as `else if (...) {` were misparsed as
   local helper methods like `if`.
4. `Nested Loops with DML/SOQL` was incorrectly reported for valid multi-line
   `SOQL-for` loops that appeared after a same-line braceless loop.
5. `Unused Methods`, `SOQL with Negative Expressions`, `SOQL with Unused Fields`,
   `SOQL with Wildcard Filter`, `Redundant SOQL`, and `Non-Restrictive Query`
   were overly noisy in `@isTest` classes.
6. `Redundant SOQL` compared duplicate query text across an entire class,
   which inflated counts when the same query shape appeared in different
   methods.
7. `Missing CRUD/FLS Check` could incorrectly point at debug text like
   `System.debug('update method')` instead of the real DML statement because
   the rule matched DML keywords inside string literals.

Example of the first case:

```apex
for (RCU__c r : rcusToNotify) rcuIds.add(r.Id);

List<RCU_Verification__c> verifications = [
    SELECT Id
    FROM RCU_Verification__c
    WHERE RCU__c IN :rcuIds
];
```

In AU org analysis, this issue caused `AUCC_RCUNotificationService` to be
incorrectly flagged at line `1335`.

Example of the second case:

```apex
for (Integration_Checklist__c obj : newRecordList) {
    // if (something) {
    System.debug(obj.Id);
    // }
}

if (!loanApplicationList.isEmpty()) {
    update loanApplicationList;
}
```

In AU org analysis, this issue caused `AUCC_VKYCInitiationController` to be
incorrectly flagged at lines `428` and `431`.

Example of the third case:

```apex
for (Database.SaveResult result : results) {
    if (!result.isSuccess()) {
        throw new AuraHandledException(buildUpdateRCUStatusErrorMessage(result));
    }
}
```

In AU org analysis, this issue caused `AUCC_RCUVerificationController` to be
incorrectly flagged with `Indirect SOQL in Loop` / `Indirect DML in Loop` at
lines `540` and `674`.

Example of the fourth case:

```apex
for (Attendance__c a : attendanceByUserDate.values()) allAttIds.add(a.Id);

for (ContentDocumentLink cdl : [
    SELECT LinkedEntityId, ContentDocumentId
    FROM ContentDocumentLink
    WHERE LinkedEntityId IN :allAttIds
]) {
    // process results
}
```

This is a valid bulk `SOQL-for` loop and should not be reported as
`Nested Loops with DML/SOQL`.

Example of the seventh case:

```apex
System.debug('update method');
if (!records.isEmpty()) update records;
```

The rule should ignore the debug string and report the real DML line.

---

## Technical Changes

- Updated `LoopDetector.find_loops()` to correctly treat same-line braceless
  loop statements as the loop body, instead of extending the loop body to the
  next non-empty statement.
- Updated loop structure parsing to ignore `//` comments while matching loop
  headers, brace depth, and braceless statement boundaries.
- Hardened local-method parsing so control-flow keywords such as `if`, `else`,
  `for`, `while`, `switch`, `catch`, `try`, and `do` can never be treated as
  helper method definitions or method calls.
- Updated nested-loop detection to recognize multi-line `SOQL-for` loops and
  avoid reporting them as nested SOQL/DML work.
- Updated CRUD/FLS detection to ignore DML keywords inside string literals and
  inline debug text, so findings point at actual `insert` / `update` /
  `delete` statements.
- Suppressed several low-signal SOQL / dead-code heuristics for Apex test
  classes so setup code does not dominate audit output.
- Scoped `Redundant SOQL` detection to duplicates within the same method
  instead of duplicates anywhere in the class.
- Added regression tests for all loop false-positive patterns fixed in this
  release plus the CRUD/FLS debug-string case.

---

## Validation

- `python3 -m unittest test_pattern_matcher.py` passes.
- Re-ran the analyzer against `AUCC_RCUNotificationService` from the AU org:
  `SOQL in Loop count: 0`.
- Re-ran the analyzer against `AUCC_VKYCInitiationController` from the AU org:
  the previous `DML in Loop` findings at lines `428` and `431` are no longer
  reported.
- Re-ran the analyzer against `AUCC_RCUVerificationController` from the AU
  org: the previous `Indirect SOQL in Loop` / `Indirect DML in Loop` findings
  at lines `540` and `674` are no longer reported.
- Added regression coverage to ensure valid multi-line `SOQL-for` loops are not
  reported as `Nested Loops with DML/SOQL`, including the
  `SRLiveStatusDashboardService`-style pattern.
- Added regression tests to ensure test classes do not emit the tuned noisy
  heuristic findings and that `Redundant SOQL` only compares queries within the
  same method.

---

## Files Changed

- `pattern_matcher.py` — fixed loop boundary parsing and blocked control-flow
  keywords from being treated as local helper methods; fixed valid multi-line
  `SOQL-for` nested-loop false positives; fixed CRUD/FLS debug-string
  misreporting; tuned noisy query/dead code heuristics for test classes;
  scoped `Redundant SOQL` to method level.
- `test_pattern_matcher.py` — added regression coverage for all AU false
  positive patterns fixed in this release plus the heuristic-noise tuning.
- `tool_version.json` — bumped to `1.2.17`.
- `latest-release.json` — updated release metadata and download URL.
