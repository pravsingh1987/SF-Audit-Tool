# Salesforce Audit Tool v1.2.14

## New Feature: Org Security Health Check Sheet

### Overview
A new **"Org Health Check"** sheet is now included in every Excel audit report. It mirrors
Salesforce's built-in Security Health Check (Setup > Security > Health Check) and provides
a structured view of 34 security and compliance settings across 9 groups.

### What's Checked (34 settings across 9 groups)

| Group | # Checks |
|-------|----------|
| Session Settings | 17 |
| Password Policies | 8 |
| Login Access Policies | 1 |
| Certificate and Key Management | 1 |
| Sharing Settings | 1 |
| Network Security | 1 |
| Remote Site Settings | 1 |
| File Upload And Download Security | 1 |
| Identity (MFA) | 1 |

### Sheet Columns
Each row in the sheet includes:
- **Risk Level** — High / Medium / Low (colour-coded red/amber/green)
- **Status** — Compliant (green) / Critical (red) / Unknown (grey)
- **Setting** — Human-readable setting name
- **Group** — Setting category
- **Your Value** — Actual value retrieved from the org
- **Standard Value** — Salesforce-recommended value
- **How to Fix (Setup Path)** — Breadcrumb navigation (e.g. `Setup > Security > Session Settings`)
- **Fix URL** — Clickable hyperlink that opens directly in Salesforce Setup
- **Details** — Additional context (e.g. certificate names, object counts)

### Data Retrieval
- **Session Settings & Password Policies** — Retrieved via `sf project retrieve start --metadata Settings:Security` (Metadata API).
- **Certificates** — Retrieved via Salesforce Tooling API (`Certificate` object).
- **Sharing Settings** — Retrieved via `EntityDefinition` (REST API) — checks for objects with public external access.
- **Network Security** — Derived from `networkAccess` section of SecuritySettings metadata.
- **Remote Site Settings** — Retrieved via Tooling API (`RemoteProxy` object).
- **MFA** — Retrieved via `MFAEnforcement` (Tooling API) with fallback to `Organization` sObject.

### New Files
- `org_health_checker.py` — New module containing `OrgHealthChecker` class and `HealthCheckItem` dataclass.

### Report Changes
- `report_generator.py` — New `_create_health_check_sheet()` method; `generate_report()` accepts new optional `health_check_items` parameter.
- `salesforce_audit.py` — New **Phase 7.5** runs health check after LWC analysis; results passed to report generator.

## What Was Already Fixed in v1.2.13 (carried forward)
- Bare DML with dotted-notation targets detected (e.g. `insert wrapper.record;`).
- `Database.SaveResult = Database.<dml>(...)` detected on correct line.
- `Nested Loops with DML/SOQL` severity corrected to Critical.
- Deduplication across overlapping/nested loops.
- `Indirect SOQL/DML in Loop` severity aligned to High.

## Validation
- Full AU org audit completed with health check: 34 checks — 17 Compliant, 14 Critical, 3 Unknown.
- All existing unit tests pass with 0 regressions.
- Fix URLs verified to navigate directly to correct Salesforce Setup pages.
