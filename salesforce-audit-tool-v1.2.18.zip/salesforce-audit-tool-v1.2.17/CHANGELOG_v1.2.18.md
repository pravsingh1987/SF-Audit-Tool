# Changelog — v1.2.18

**Release Date**: 2026-08-03  
**Previous Version**: v1.2.17  
**File**: `sf_utils.py`, `run_audit.sh`

---

## Summary

v1.2.18 resolves two critical compatibility issues introduced by the **Salesforce CLI v2 (sf)** security update and an **org-storage-type limitation** on `FieldDefinition` that blocked audits from completing on certain customer sandboxes (e.g., HDFC Bank UAT).

---

## Bug Fixes

### Fix 1 — SF CLI v2 Access Token Redaction (`INVALID_AUTH_HEADER`)

**File**: `sf_utils.py` — `SalesforceConnector._connect_sfdx()`

**Problem**:  
Salesforce CLI v2 deliberately hides access tokens in the output of `sf org display` (and the legacy `sfdx force:org:display`) for security reasons. The token field now returns the placeholder string:

```
[REDACTED] Use 'sf org auth show-access-token' to view
```

The audit tool passed this placeholder directly to `simple-salesforce` as the `session_id`, which resulted in:

```
INVALID_AUTH_HEADER: Invalid authorization header
```

**Root cause**: The `_connect_sfdx()` method used a single command (`sfdx force:org:display`) to retrieve both `instanceUrl` and `accessToken` in one call — a pattern that no longer works in SF CLI v2.

**Fix**:  
Replaced the single-command approach with a two-step SF CLI v2 call:

1. `sf org display --target-org <alias> --json` → retrieves `instanceUrl`
2. `sf org auth show-access-token --target-org <alias> --json` → retrieves the actual access token

```python
# Step 1 — instance URL
display_result = subprocess.run(
    ['sf', 'org', 'display', '--target-org', org_alias, '--json'], ...
)
self.instance_url = display_data['result']['instanceUrl']

# Step 2 — real access token (not redacted)
token_result = subprocess.run(
    ['sf', 'org', 'auth', 'show-access-token', '--target-org', org_alias, '--json'], ...
)
access_token = token_data['result']['accessToken']
```

**Additional hardening**:
- Detects `[REDACTED]` in any returned token string and raises a clear, actionable error with the fix command rather than letting `simple-salesforce` raise a confusing `INVALID_AUTH_HEADER`.
- Gracefully falls back to the legacy `sfdx force:org:display` command if the modern `sf` CLI is not installed.
- Validates that `instanceUrl` was retrieved before attempting token fetch.

**Affected orgs**: All orgs when using Salesforce CLI v2.145.x or newer.

---

### Fix 2 — `FieldDefinition` INVALID_OPERATION on Certain Org Storage Types

**File**: `sf_utils.py` — `MetadataRetriever.get_custom_fields()`

**Problem**:  
On some Salesforce org storage configurations (notably HDFC Bank UAT, and previously AU Small Finance Bank), the standard REST API `FieldDefinition` query throws:

```
INVALID_OPERATION: The requested operation is not yet supported by this sObject storage type,
contact salesforce.com support for more information.
```

The audit tool logged this as an error and returned `0 custom fields`, causing the custom fields count in the report to be incorrect.

**Root cause**: The `FieldDefinition` sObject is not supported on all Salesforce storage backends (a Salesforce platform limitation, not a bug in the tool).

**Fix**:  
The `get_custom_fields()` method now uses a **three-strategy fallback chain**:

| Strategy | API | Query | Triggered when |
|---|---|---|---|
| 1 | Standard REST API | `SELECT … FROM FieldDefinition WHERE …` | Default — used on all supported orgs |
| 2 | Tooling API | `SELECT … FROM CustomField WHERE ManageableState='unmanaged'` | Strategy 1 raises `INVALID_OPERATION` |
| 3 | Tooling API count | `SELECT COUNT() FROM CustomField …` | Strategies 1 & 2 both fail — returns count only, audit continues |

Strategy 2 (Tooling API `CustomField`) is functionally equivalent to Strategy 1 and produces identically-shaped result records that the rest of the tool processes without any changes.

Strategy 3 ensures the audit **never crashes** on custom field retrieval — it degrades gracefully with a warning and continues.

**Affected orgs**: HDFC Bank UAT, AU Small Finance Bank (previously), and any org with a non-standard Salesforce storage backend.

---

### Fix 3 — `run_audit.sh` Updated for SF CLI v2

**File**: `run_audit.sh`

**Problem**:  
The shell script used `sfdx org list` and `sfdx auth:web:login` — both deprecated commands that produce warnings or errors under SF CLI v2.

**Fix**:
- Auto-detects whether `sf` (v2) or `sfdx` (legacy) is available and sets `SF_CMD` accordingly.
- Updated org listing to handle both SF CLI v2 JSON format (`result.nonScratchOrgs`) and flat list format.
- Updated authentication call: `sfdx auth:web:login` → `sf org login web`.

---

## Upgrade Instructions

1. Download `salesforce-audit-tool-v1.2.18.zip` from GitHub.
2. Extract alongside (or replacing) your existing `salesforce-audit-tool-v1.2.17/` folder.
3. Copy your `config.yaml` and `update_config.json` from v1.2.17 to v1.2.18 if present.
4. **Fix the SF CLI log file permission error** (if you see `EPERM: operation not permitted`):
   ```bash
   rm -f /Users/<you>/.sf/sf-$(date +%Y-%m-%d).log
   # or permanently suppress the log file:
   echo 'export SF_DISABLE_LOG_FILE=true' >> ~/.zshrc && source ~/.zshrc
   ```
5. Run the audit:
   ```bash
   cd salesforce-audit-tool-v1.2.18
   SF_DISABLE_LOG_FILE=true python3 salesforce_audit.py --sfdx <org-alias>
   ```

---

## Compatibility

| Salesforce CLI | Status |
|---|---|
| `sf` v2.145.x+ | ✅ Fully supported (primary path) |
| `sfdx` legacy | ✅ Supported via automatic fallback |
| Neither installed | ❌ Install SF CLI from https://developer.salesforce.com/tools/salesforcecli |

| Org Type | Custom Fields Strategy |
|---|---|
| Standard storage | Strategy 1 — `FieldDefinition` REST API |
| Non-standard storage (HDFC UAT, AU SFB) | Strategy 2 — Tooling API `CustomField` |
| Both strategies fail | Strategy 3 — count only, audit continues |
