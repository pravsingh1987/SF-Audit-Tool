import unittest

from pattern_matcher import analyze_apex_code


class LoopDetectionTests(unittest.TestCase):
    def get_loop_findings(self, code: str):
        return [
            (violation.violation_type.value, violation.line_number, violation.call_chain)
            for violation in analyze_apex_code("Sample.cls", code, is_trigger=False)
            if "Loop" in violation.violation_type.value or "Indirect" in violation.violation_type.value
        ]

    def test_detects_direct_soql_and_dml_in_loops(self):
        code = """public class Sample {
    void run(List<Account> accounts){
        for(Account account : accounts){
            List<Contact> contacts = [SELECT Id FROM Contact WHERE AccountId = :account.Id];
            update account;
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("SOQL in Loop", 4, None), findings)
        self.assertIn(("DML in Loop", 5, None), findings)

    def test_detects_multiline_and_dynamic_soql_in_loops(self):
        code = """public class Sample {
    void run(List<Account> accounts){
        for(Account account : accounts){
            List<Contact> contacts = [
                SELECT Id
                FROM Contact
                WHERE AccountId = :account.Id
            ];
            List<SObject> rows = Database.query('SELECT Id FROM Account WHERE Name = \\'Acme\\'');
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("SOQL in Loop", 4, None), findings)
        self.assertIn(("SOQL in Loop", 9, None), findings)

    def test_detects_indirect_soql_and_dml_in_loops(self):
        code = """public class Sample {
    List<Contact> loadContacts(Id accountId){
        return [SELECT Id FROM Contact WHERE AccountId = :accountId];
    }
    void saveOne(Account account){
        update account;
    }
    void run(List<Account> accounts){
        for(Account account : accounts){
            loadContacts(account.Id);
            saveOne(account);
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("Indirect SOQL in Loop", 10, ["loadContacts"]), findings)
        self.assertIn(("Indirect DML in Loop", 11, ["saveOne"]), findings)

    def test_detects_transitive_helper_chain(self):
        code = """public class Sample {
    void saveInner(Account account){
        update account;
    }
    void saveOuter(Account account){
        saveInner(account);
    }
    void run(List<Account> accounts){
        for(Account account : accounts){
            saveOuter(account);
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("Indirect DML in Loop", 10, ["saveOuter", "saveInner"]), findings)

    def test_detects_dml_when_assigned_to_database_save_result(self):
        code = """public class Sample {
    void run(List<Account> accounts){
        for(Account account : accounts){
            Database.SaveResult result = Database.update(account, false);
            Database.SaveResult[] bulk = Database.update(accounts, false);
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("DML in Loop", 4, None), findings)
        self.assertIn(("DML in Loop", 5, None), findings)

    def test_dml_in_loop_not_duplicated_for_nested_loops(self):
        code = """public class Sample {
    void run(List<Account> outer, List<Account> inner){
        for(Account a : outer){
            for(Account b : inner){
                Database.SaveResult sr = Database.update(b, false);
            }
        }
    }
}"""
        findings = [
            f for f in self.get_loop_findings(code)
            if f[0] == "DML in Loop"
        ]
        self.assertEqual(findings, [("DML in Loop", 5, None)])

    def test_nested_loops_with_dml_reports_critical_once(self):
        code = """public class Sample {
    void run(List<Account> outer, List<Account> inner){
        for(Account a : outer){
            for(Account b : inner){
                Database.SaveResult sr = Database.update(b, false);
            }
        }
    }
}"""
        from pattern_matcher import analyze_apex_code as _ana
        nested = [
            v for v in _ana("Sample.cls", code)
            if v.violation_type.value == "Nested Loops with DML/SOQL"
        ]
        self.assertEqual(len(nested), 1, msg=f"Expected single nested-loop violation, got {nested}")
        self.assertEqual(nested[0].line_number, 5)
        self.assertEqual(nested[0].criticality, "Critical")

    def test_avoids_false_positives_for_indexing_or_non_loop_helper_calls(self):
        code = """public class Sample {
    List<Contact> loadContacts(Id accountId){
        return [SELECT Id FROM Contact WHERE AccountId = :accountId];
    }
    void run(List<Account> accounts){
        Account firstAccount = accounts[0];
        loadContacts(firstAccount.Id);
        for(Integer i = 0; i < accounts.size(); i++){
            Account currentAccount = accounts[i];
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertEqual([], findings)

    def test_same_line_braceless_loop_does_not_capture_following_query(self):
        code = """public class Sample {
    void run(List<Account> accounts){
        Set<Id> accountIds = new Set<Id>();
        for(Account account : accounts) accountIds.add(account.Id);

        List<Contact> contacts = [
            SELECT Id
            FROM Contact
            WHERE AccountId IN :accountIds
        ];
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertEqual([], findings)

    def test_commented_braces_inside_loop_do_not_extend_loop_scope(self):
        code = """public class Sample {
    void run(List<Account> accounts, List<Account> updates){
        for(Account account : accounts){
            // if(account.Name == 'Acme') {
            System.debug(account.Id);
            // }
        }

        if(!updates.isEmpty()){
            update updates;
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertEqual([], findings)

    def test_control_flow_is_not_treated_as_indirect_helper_method(self):
        code = """public class Sample {
    void run(List<Account> accounts){
        for(Account account : accounts){
            Database.SaveResult[] results = Database.update(accounts, false);
            for(Database.SaveResult result : results){
                if(!result.isSuccess()){
                    System.debug(result.getErrors());
                }
            }
        }
    }

    void realHelper(){
        List<Contact> contacts = [SELECT Id FROM Contact];
        update contacts;
    }

    void other(Boolean allProcessed){
        if (allProcessed) {
            System.debug('first branch');
        } else if (allProcessed) {
            System.debug('not a method');
        }
    }
}"""
        findings = [
            finding for finding in self.get_loop_findings(code)
            if finding[0] in ("Indirect SOQL in Loop", "Indirect DML in Loop")
        ]
        self.assertEqual([], findings)

    def test_soql_for_loop_is_not_reported_as_nested_loop_false_positive(self):
        code = """public class Sample {
    void run(Map<Id, Account> accountMap, Set<Id> ids){
        for(Account acc : accountMap.values()) ids.add(acc.Id);

        if(!ids.isEmpty()){
            for(Contact c : [
                SELECT Id, AccountId
                FROM Contact
                WHERE AccountId IN :ids
            ]){
                System.debug(c.Id);
            }
        }
    }
}"""
        findings = [
            finding for finding in self.get_loop_findings(code)
            if finding[0] == "Nested Loops with DML/SOQL"
        ]
        self.assertEqual([], findings)


class SharedSoqlRuleRegressionTests(unittest.TestCase):
    def get_findings(self, code: str):
        return [
            (violation.violation_type.value, violation.line_number)
            for violation in analyze_apex_code("Sample.cls", code, is_trigger=False)
        ]

    def assertHasFinding(self, findings, rule_name, line_number):
        self.assertIn((rule_name, line_number), findings)

    def test_non_loop_soql_rules_keep_reporting_expected_lines(self):
        cases = [
            (
                """public class Sample {
    void run(){
        List<Account> accs = [
            SELECT Id, Name
            FROM Account
        ];
    }
}""",
                "SOQL Without a WHERE Clause or LIMIT Statement",
                3,
            ),
            (
                """public class Sample {
    void run(){
        List<Account> accs = [SELECT Id, Name FROM Account WHERE Name LIKE '%Acme%'];
    }
}""",
                "SOQL with Wildcard Filter",
                3,
            ),
            (
                """public class Sample {
    void run(){
        List<Account> accs = [SELECT Id, Name FROM Account WHERE Name != 'Acme'];
    }
}""",
                "SOQL with Negative Expressions",
                3,
            ),
            (
                """public class Sample {
    void run(){
        List<Account> accs = [SELECT Id, Name, Industry FROM Account WHERE Name = 'Acme'];
        for(Account acc : accs){
            System.debug(acc.Name);
        }
    }
}""",
                "SOQL with Unused Fields",
                3,
            ),
            (
                """public class Sample {
    void run(){
        List<Account> accs = [SELECT Id, Name FROM Account];
        for(Account acc : accs){
            if(acc.Name == 'Acme'){
                System.debug(acc.Id);
            }
        }
    }
}""",
                "SOQL with Apex Filter",
                3,
            ),
            (
                """public class Sample {
    void run(String name){
        List<SObject> rows = Database.query('SELECT Id FROM Account WHERE Name = \\'" + name + "\\'');
    }
}""",
                "SOQL Injection Risk",
                3,
            ),
        ]

        for code, rule_name, line_number in cases:
            with self.subTest(rule=rule_name):
                findings = self.get_findings(code)
                self.assertHasFinding(findings, rule_name, line_number)

    def test_soql_for_loop_remains_allowed_for_loop_rule(self):
        code = """public class Sample {
    void run(){
        for(Account account : [SELECT Id FROM Account]){
            System.debug(account.Id);
        }
    }
}"""
        findings = self.get_findings(code)
        loop_rules = {
            "SOQL in Loop",
            "DML in Loop",
            "Indirect SOQL in Loop",
            "Indirect DML in Loop",
        }
        self.assertFalse(any(rule_name in loop_rules for rule_name, _ in findings))


class HeuristicNoiseTuningTests(unittest.TestCase):
    def get_findings(self, file_name: str, code: str):
        return [
            (violation.violation_type.value, violation.line_number)
            for violation in analyze_apex_code(file_name, code, is_trigger=False)
        ]

    def test_query_heuristics_are_suppressed_for_test_classes(self):
        code = """@isTest
private class SampleTest {
    private static void helperOne() {
        List<Account> rows = [SELECT Id, Name, Industry FROM Account WHERE Name != 'Acme'];
        List<Account> rowsAgain = [SELECT Id, Name, Industry FROM Account WHERE Name != 'Acme'];
        List<Account> wildcardRows = [SELECT Id, Name FROM Account WHERE Name LIKE '%Acme%'];
        List<Account> broadRows = [SELECT Id, Name FROM Account];
        System.debug(rows);
        System.debug(rowsAgain);
        System.debug(wildcardRows);
        System.debug(broadRows);
    }

    private static void helperUnused() {
        System.debug('unused');
    }
}"""
        findings = self.get_findings("SampleTest.cls", code)
        noisy_rules = {
            "Unused Methods",
            "SOQL with Negative Expressions",
            "SOQL with Unused Fields",
            "SOQL with Wildcard Filter",
            "Redundant SOQL",
            "Non-Restrictive Query",
            "SOQL Without a WHERE Clause or LIMIT Statement",
        }
        self.assertFalse(any(rule_name in noisy_rules for rule_name, _ in findings), findings)

    def test_redundant_soql_only_counts_duplicates_within_same_method(self):
        code = """public class Sample {
    void first(Id accountId){
        List<Account> a = [SELECT Id FROM Account WHERE Id = :accountId];
    }
    void second(Id accountId){
        List<Account> b = [SELECT Id FROM Account WHERE Id = :accountId];
    }
}"""
        findings = self.get_findings("Sample.cls", code)
        self.assertNotIn(("Redundant SOQL", 6), findings)

    def test_redundant_soql_still_flags_duplicates_within_same_method(self):
        code = """public class Sample {
    void run(Id accountId){
        List<Account> a = [SELECT Id FROM Account WHERE Id = :accountId];
        List<Account> b = [SELECT Id FROM Account WHERE Id = :accountId];
    }
}"""
        findings = self.get_findings("Sample.cls", code)
        self.assertIn(("Redundant SOQL", 4), findings)


class CrudFlsDetectionTests(unittest.TestCase):
    def test_crud_fls_ignores_debug_text_and_reports_actual_dml_line(self):
        code = """public with sharing class HBCApprovalHelper {
    public static void run(List<Account> records) {
        System.debug('update method');
        if (!records.isEmpty()) update records;
    }
}"""
        findings = [
            v for v in analyze_apex_code("HBCApprovalHelper.cls", code, is_trigger=False)
            if v.violation_type.value == "Missing CRUD/FLS Check"
        ]

        self.assertEqual(1, len(findings), findings)
        self.assertEqual(4, findings[0].line_number)
        self.assertEqual("if (!records.isEmpty()) update records;", findings[0].code_snippet)


if __name__ == "__main__":
    unittest.main()
