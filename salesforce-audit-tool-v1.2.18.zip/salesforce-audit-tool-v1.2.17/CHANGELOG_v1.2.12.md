# Salesforce Audit Tool v1.2.12

## Bug Fixes

### DML Detection – Correct Line Numbers for `Database.SaveResult = Database.<dml>(...)` Patterns
- Previously, `DMLDetector.is_dml_statement()` skipped lines that started with a type declaration (e.g. `Database.SaveResult`), causing `Database.SaveResult x = Database.update(records, false);` to be silently ignored.
- The detector now checks for a `Database.<dml>(...)` call **anywhere** on the line before applying the variable-declaration filter.
- This fixes the bug where all DML-in-loop violations in a class collapsed to a single incorrect line number (e.g. all showing line 278 instead of the correct distinct lines 251, 278, 339).

### Nested Loops with DML/SOQL – Severity Corrected to Critical
- `Nested Loops with DML/SOQL` was being reported as `High` by the detector, which did not match the rules-reference catalog entry (`Critical`).
- Fixed to emit `Critical` consistently, matching the documented severity.

### Deduplication of Violations Across Overlapping Loops
- When DML/SOQL lines sat inside multiple nested loops, each was reported once per enclosing loop, producing duplicate violation rows for the same line.
- Applied deduplication (`reported_lines` guard) to all loop-iterating checks:
  - `_check_soql_in_loops`
  - `_check_dml_in_loops`
  - `_check_indirect_loop_operations`
  - `_check_nested_loops`
  - `_check_schema_getglobaldescribe_in_loops`
  - `_check_expensive_methods_in_loops`
  - `_check_limits_getheapsize_in_loop`

### Indirect SOQL/DML in Loop – Severity Aligned to Rules Table
- `Indirect SOQL in Loop` and `Indirect DML in Loop` were being emitted as `Critical` by the detector, but the rules-reference catalog documents them as `High` (indirect violations are less severe than direct ones).
- Corrected the detector to emit `High`, consistent with the reference table.

## Validation

- Added 3 new regression tests to `test_pattern_matcher.py`:
  - `test_detects_dml_when_assigned_to_database_save_result` – verifies `Database.SaveResult = Database.update(...)` is detected on the correct line.
  - `test_dml_in_loop_not_duplicated_for_nested_loops` – verifies the same DML line is reported exactly once regardless of how many loops contain it.
  - `test_nested_loops_with_dml_reports_critical_once` – verifies `Nested Loops with DML/SOQL` reports exactly one `Critical` violation per offending line.
- All 10 unit tests pass with 0 regressions.
