# Changelog — v1.2.16

**Release Date:** 2026-05-06

---

## New Feature — Additional Browser & Session Security Checks

Six new security checks have been added to the **Org Health Check** sheet under
a dedicated **"Browser & Session Security"** section (visually separated by a
blue divider row).

These settings are sourced directly from the `SecuritySettings` metadata XML
(retrieved via `sf project retrieve start`) because Salesforce's own
`SecurityHealthCheckRisks` Tooling API does not yet cover them.

| Risk | Setting | Source field |
|------|---------|--------------|
| Medium | Cross-Origin Opener Policy (COOP) | `sessionSettings.enableCoopHeader` |
| Medium | Cross-Origin Embedder Policy (COEP) | `sessionSettings.enableCoepHeader` |
| Medium | Apply CSP directives for less common browsers | `sessionSettings.sendCspForUncommonClients` |
| Low | Override Restriction on Email Templates in Classic/IE | *(manual — not in Metadata API)* |
| Medium | Use POST requests for cross-domain sessions | `sessionSettings.enablePostForSessions` |
| Low | Enable secure and persistent browser caching | `sessionSettings.enableCacheAndAutocomplete` |

> **IE Email Template note:** This Classic/IE-specific setting has no Metadata
> API equivalent. The tool marks it as **Unknown** with a direct link to
> Setup > Session Settings and guidance to verify manually.

### Health Check totals
- v1.2.15: 44 checks (Tooling API only)
- v1.2.16: **50 checks** (44 Tooling API + 6 browser security from XML)

---

## Report Changes

- A blue section divider row is inserted before the supplementary "Browser &
  Session Security" block to visually distinguish it from the Salesforce
  Health Check data.

---

## Files Changed
- `org_health_checker.py` — added `BrowserSecurityHeaders` group, new
  `_check_browser_security_headers()` method, updated `run_health_check()`
  to always retrieve SecuritySettings XML and append supplementary checks.
- `report_generator.py` — added blue section divider row logic.
- `tool_version.json` — bumped to `1.2.16`.
- `latest-release.json` — updated download URL.

---

## Carried Forward
- All v1.2.15 fixes (live Tooling API for health check, correct Fix URLs)
- All v1.2.14 additions (Org Health Check sheet)
- All v1.2.13/v1.2.12 bug fixes (DML detection, severity, deduplication)
