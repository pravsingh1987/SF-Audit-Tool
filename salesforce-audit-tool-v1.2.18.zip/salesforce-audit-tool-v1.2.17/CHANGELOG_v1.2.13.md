# Salesforce Audit Tool v1.2.13

## Bug Fixes

### DML Detection – Dotted-Notation Targets Now Correctly Identified
- Previously, `DMLDetector.is_dml_statement()` matched bare DML only when the target was a simple variable name (e.g. `insert record;`).
- DML statements whose targets use dotted property access (e.g. `insert inputWrapper.integrationChecklistRecord;`) or array indexing (e.g. `insert wrappers[0];`) were silently skipped, causing those violations to be missed entirely.
- `DML_STATEMENT_PATTERN` regex updated from:
  ```
  ^\s*(insert|update|delete|upsert|undelete)\s+[a-zA-Z_]\w*\s*;
  ```
  to:
  ```
  ^\s*(insert|update|delete|upsert|undelete)\s+[a-zA-Z_]\w*(?:\.[a-zA-Z_]\w*|\[\d+\])*\s*;
  ```
- Example previously missed and now correctly flagged:
  - `insert inputWrapper.integrationChecklistRecord;` (line 101, `AUCC_INT_FICOEligibility_Handler`)

## What Was Already Fixed in v1.2.12 (carried forward)
- `Database.SaveResult = Database.<dml>(...)` patterns detected on the correct line.
- `Nested Loops with DML/SOQL` severity corrected to **Critical**.
- Deduplication across overlapping/nested loops (no more repeated violations for the same line).
- `Indirect SOQL/DML in Loop` severity aligned to **High** (matching the rules-reference catalog).

## Validation
- All existing unit tests continue to pass with 0 regressions.
- Verified against `AUCC_INT_FICOEligibility_Handler` (AU org): DML at line 101 is now flagged as **Critical – DML in Loop**.
- Full re-audit of AU org (591 classes, 23 triggers) completed cleanly under v1.2.13 with correct violation counts.
