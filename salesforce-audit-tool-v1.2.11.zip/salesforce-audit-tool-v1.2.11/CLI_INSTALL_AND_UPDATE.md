# CLI Install And Update Guide

This guide is for end users who want to install the Salesforce Audit Tool for the first time and later update it from the command line.

Current version in this package: `1.2.11`

## Prerequisites

Make sure these are installed first:

- `python3`
- `git`
- Salesforce CLI (`sfdx` or `sf`)
- access to the distributed zip file

Check from terminal:

```bash
python3 --version
git --version
sfdx --version
```

## First-Time Installation

### 1. Download the zip

Download the latest tool zip provided by the Salesforce architecture team.

Example filename:

```bash
salesforce-audit-tool-v1.2.11.zip
```

### 2. Unzip the package

```bash
unzip salesforce-audit-tool-v1.2.11.zip
cd salesforce-audit-tool-v1.2.11
```

### 3. Install Python dependencies

```bash
python3 -m pip install -r requirements.txt
```

### 4. Authenticate to Salesforce

Production:

```bash
sfdx auth:web:login -a myorg
```

Sandbox:

```bash
sfdx auth:web:login -a myorg -r https://test.salesforce.com
```

### 5. Run the audit

```bash
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

## First-Time Installation Directly From Git

If the repository is accessible to the user, they can install directly from Git instead of using the zip.

### 1. Clone the repository

```bash
git clone https://git.soma.salesforce.com/praveensingh/PS-SF-Audit-Tool.git
cd PS-SF-Audit-Tool
```

### 2. Install Python dependencies

```bash
python3 -m pip install -r requirements.txt
```

### 3. Authenticate to Salesforce

Production:

```bash
sfdx auth:web:login -a myorg
```

Sandbox:

```bash
sfdx auth:web:login -a myorg -r https://test.salesforce.com
```

### 4. Run the audit

```bash
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

## First-Time Installation Using The Launcher Script

If you prefer the helper script:

```bash
chmod +x run_audit.sh
./run_audit.sh
```

Or:

```bash
./run_audit.sh myorg ./audit-results
```

## How To Check For A New Version

Run this command from inside the tool folder:

```bash
python3 salesforce_audit.py --check-updates
```

Possible results:

- `You are already on the latest version`
- `Update available: vX.Y.Z`
- an update/install prompt if a newer version is published

## How To Update To A New Version

### Option 1. Recommended: use the built-in updater

From your current installed folder:

```bash
python3 salesforce_audit.py
```

or:

```bash
python3 salesforce_audit.py --check-updates
```

If a newer version is available, the tool prompts you to install it.

To install without waiting for a prompt:

```bash
python3 salesforce_audit.py --check-updates --yes-update
```

### Option 2. Manual update

If you receive a new zip manually, install it like this:

```bash
unzip salesforce-audit-tool-v1.2.11.zip
cd salesforce-audit-tool-v1.2.11
python3 -m pip install -r requirements.txt
```

Then run:

```bash
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

### Option 3. Update a Git-based installation

If the tool was installed using `git clone`, update it like this:

```bash
cd PS-SF-Audit-Tool
git pull
python3 -m pip install -r requirements.txt
```

Then run:

```bash
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

## Recommended Commands Summary

First-time install:

```bash
unzip salesforce-audit-tool-v1.2.11.zip
cd salesforce-audit-tool-v1.2.11
python3 -m pip install -r requirements.txt
sfdx auth:web:login -a myorg
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

First-time install from Git:

```bash
git clone https://git.soma.salesforce.com/praveensingh/PS-SF-Audit-Tool.git
cd PS-SF-Audit-Tool
python3 -m pip install -r requirements.txt
sfdx auth:web:login -a myorg
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

Check for updates:

```bash
python3 salesforce_audit.py --check-updates
```

Install latest available update:

```bash
python3 salesforce_audit.py --check-updates --yes-update
```

Update a Git-based install:

```bash
cd PS-SF-Audit-Tool
git pull
python3 -m pip install -r requirements.txt
```

Run the audit after update:

```bash
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

## Troubleshooting

### `command not found: pip`

Use:

```bash
python3 -m pip install -r requirements.txt
```

### `No authenticated orgs found`

Authenticate first:

```bash
sfdx auth:web:login -a myorg
```

### `Update check failed`

This usually means the update manifest URL or zip URL is not reachable from your machine. Contact the Salesforce architecture team.

## Notes

- Keep `update_config.json` inside the tool folder.
- Run update commands from inside the currently installed tool directory.
- The updater only prompts when a newer version than your current local version is published.
