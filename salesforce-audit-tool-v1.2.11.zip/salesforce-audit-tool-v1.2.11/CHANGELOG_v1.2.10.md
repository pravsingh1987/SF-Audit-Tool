# Salesforce Audit Tool v1.2.10

## Loop Detection Coverage

- Added same-file helper-method tracing for `Indirect SOQL in Loop` and `Indirect DML in Loop`
- Detects transitive helper chains, so loop calls like `saveOuter()` -> `saveInner()` -> `update` are now flagged
- Detects inline multiline SOQL where `[` and `SELECT` are split across lines
- Detects `Database.query()`, `Database.queryWithBinds()`, and `Database.getQueryLocator()` when executed inside loops
- Improved nested-loop checks to treat dynamic SOQL the same as inline SOQL

## Validation

- Added `test_pattern_matcher.py` regression tests covering direct, indirect, dynamic, and multiline loop scenarios
- Verified line numbers continue to align with source even when block comments are present
