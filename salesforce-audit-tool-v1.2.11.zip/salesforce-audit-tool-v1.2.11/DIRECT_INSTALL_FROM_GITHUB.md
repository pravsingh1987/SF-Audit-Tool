# Direct Install From GitHub

This guide is for first-time users who want to install the Salesforce Audit Tool directly from the GitHub-hosted release zip, and for existing users who want to update when a new version is published.

Current published version:

- `1.2.11`

Current download URL:

- `https://github.com/pravsingh1987/SF-Audit-Tool/raw/refs/heads/main/salesforce-audit-tool-v1.2.11.zip`

## Prerequisites

Make sure these are available in terminal:

- `python3`
- `unzip`
- Salesforce CLI (`sfdx`)

Check:

```bash
python3 --version
unzip -v
sfdx --version
```

## First-Time Install

### One-shot install command

This command reads `latest-release.json`, downloads the latest published zip, extracts it, and installs dependencies:

```bash
python3 - <<'PY'
import json, urllib.request, os, zipfile, subprocess, sys

manifest_url = "https://github.com/pravsingh1987/SF-Audit-Tool/raw/refs/heads/main/latest-release.json"
manifest = json.load(urllib.request.urlopen(manifest_url))
zip_url = manifest["download_url"]
zip_name = zip_url.split("/")[-1]
folder = zip_name[:-4]

urllib.request.urlretrieve(zip_url, zip_name)

with zipfile.ZipFile(zip_name, "r") as zf:
    zf.extractall(".")

subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", os.path.join(folder, "requirements.txt")])
print(f"Installed in ./{folder}")
PY
```

Then authenticate and run from the installed folder:

```bash
cd salesforce-audit-tool-v1.2.11
sfdx auth:web:login -a myorg
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

### Step-by-step alternative

### 1. Download the latest zip

```bash
curl -L -o salesforce-audit-tool-v1.2.11.zip "https://github.com/pravsingh1987/SF-Audit-Tool/raw/refs/heads/main/salesforce-audit-tool-v1.2.11.zip"
```

If `curl` is not available, download the zip in the browser and place it in your working folder.

### 2. Extract the zip

```bash
unzip salesforce-audit-tool-v1.2.11.zip
cd salesforce-audit-tool-v1.2.11
```

### 3. Install dependencies

```bash
python3 -m pip install -r requirements.txt
```

### 4. Authenticate to Salesforce

Production:

```bash
sfdx auth:web:login -a myorg
```

Sandbox:

```bash
sfdx auth:web:login -a myorg -r https://test.salesforce.com
```

### 5. Run the audit

```bash
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

## Check For Updates

From inside your installed tool folder:

```bash
python3 salesforce_audit.py --check-updates
```

If a newer version is available, the tool will tell you.

## Update To The Latest Published Version

### Option 1. Use the built-in updater

From your current tool folder:

```bash
python3 salesforce_audit.py
```

or:

```bash
python3 salesforce_audit.py --check-updates
```

To install the update without waiting for a prompt:

```bash
python3 salesforce_audit.py --check-updates --yes-update
```

### Option 2. Download the newer zip manually

When a new version is published, replace `1.2.11` with the new version number in the commands below.

Example for `1.2.11`:

```bash
curl -L -o salesforce-audit-tool-v1.2.11.zip "https://github.com/pravsingh1987/SF-Audit-Tool/raw/refs/heads/main/salesforce-audit-tool-v1.2.11.zip"
unzip salesforce-audit-tool-v1.2.11.zip
cd salesforce-audit-tool-v1.2.11
python3 -m pip install -r requirements.txt
```

Then run:

```bash
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

## Generic Commands For Any Future Version

Replace `X.Y.Z` with the published release version.

### First-time install

```bash
curl -L -o salesforce-audit-tool-vX.Y.Z.zip "https://github.com/pravsingh1987/SF-Audit-Tool/raw/refs/heads/main/salesforce-audit-tool-vX.Y.Z.zip" && unzip -q salesforce-audit-tool-vX.Y.Z.zip && cd salesforce-audit-tool-vX.Y.Z && python3 -m pip install -r requirements.txt
```

### Manual update to a newer version

```bash
curl -L -o salesforce-audit-tool-vX.Y.Z.zip "https://github.com/pravsingh1987/SF-Audit-Tool/raw/refs/heads/main/salesforce-audit-tool-vX.Y.Z.zip"
unzip salesforce-audit-tool-vX.Y.Z.zip
cd salesforce-audit-tool-vX.Y.Z
python3 -m pip install -r requirements.txt
```

## Recommended End-User Commands

First-time setup:

```bash
python3 - <<'PY'
import json, urllib.request, os, zipfile, subprocess, sys

manifest_url = "https://github.com/pravsingh1987/SF-Audit-Tool/raw/refs/heads/main/latest-release.json"
manifest = json.load(urllib.request.urlopen(manifest_url))
zip_url = manifest["download_url"]
zip_name = zip_url.split("/")[-1]
folder = zip_name[:-4]

urllib.request.urlretrieve(zip_url, zip_name)

with zipfile.ZipFile(zip_name, "r") as zf:
    zf.extractall(".")

subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", os.path.join(folder, "requirements.txt")])
print(f"Installed in ./{folder}")
PY
cd salesforce-audit-tool-v1.2.11
sfdx auth:web:login -a myorg
python3 salesforce_audit.py --sfdx myorg --output-dir ./audit-results
```

Check for updates later:

```bash
python3 salesforce_audit.py --check-updates
```

Install the latest available update:

```bash
python3 salesforce_audit.py --check-updates --yes-update
```

## Troubleshooting

### `command not found: pip`

Use:

```bash
python3 -m pip install -r requirements.txt
```

### `No authenticated orgs found`

Authenticate first:

```bash
sfdx auth:web:login -a myorg
```

### `Update check failed`

This usually means:

- the manifest URL is unreachable from your machine
- the published zip URL is wrong
- network restrictions are blocking GitHub access

## Notes

- Run update commands from inside the currently installed tool folder.
- The updater only prompts when a newer version than your current local version exists.
- For manual updates, install into the new versioned folder and run from that folder.
