# Salesforce Audit Tool v1.2.11

## Packaging and Release

- Bumped the package version to `1.2.11` across tool metadata, updater manifests, scripts, and release docs
- Added the refreshed PDF executive summary layout and metadata snapshot/grading sections to the packaged release
- Prepared the next-version distributable zip naming for `salesforce-audit-tool-v1.2.11.zip`

## Included Improvements

- Broader loop detection for direct, multiline, dynamic, and same-file indirect SOQL/DML patterns
- Cleaner PDF output without raw HTML-style tags and with better executive readability
- Dynamic PDF metadata fields for the audited org, plus `Why This Grade?`, `Next Better Grade`, and `Grading Reference`
