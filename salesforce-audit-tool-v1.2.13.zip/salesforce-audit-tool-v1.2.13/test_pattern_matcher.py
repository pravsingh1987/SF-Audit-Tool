import unittest

from pattern_matcher import analyze_apex_code


class LoopDetectionTests(unittest.TestCase):
    def get_loop_findings(self, code: str):
        return [
            (violation.violation_type.value, violation.line_number, violation.call_chain)
            for violation in analyze_apex_code("Sample.cls", code, is_trigger=False)
            if "Loop" in violation.violation_type.value or "Indirect" in violation.violation_type.value
        ]

    def test_detects_direct_soql_and_dml_in_loops(self):
        code = """public class Sample {
    void run(List<Account> accounts){
        for(Account account : accounts){
            List<Contact> contacts = [SELECT Id FROM Contact WHERE AccountId = :account.Id];
            update account;
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("SOQL in Loop", 4, None), findings)
        self.assertIn(("DML in Loop", 5, None), findings)

    def test_detects_multiline_and_dynamic_soql_in_loops(self):
        code = """public class Sample {
    void run(List<Account> accounts){
        for(Account account : accounts){
            List<Contact> contacts = [
                SELECT Id
                FROM Contact
                WHERE AccountId = :account.Id
            ];
            List<SObject> rows = Database.query('SELECT Id FROM Account WHERE Name = \\'Acme\\'');
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("SOQL in Loop", 4, None), findings)
        self.assertIn(("SOQL in Loop", 9, None), findings)

    def test_detects_indirect_soql_and_dml_in_loops(self):
        code = """public class Sample {
    List<Contact> loadContacts(Id accountId){
        return [SELECT Id FROM Contact WHERE AccountId = :accountId];
    }
    void saveOne(Account account){
        update account;
    }
    void run(List<Account> accounts){
        for(Account account : accounts){
            loadContacts(account.Id);
            saveOne(account);
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("Indirect SOQL in Loop", 10, ["loadContacts"]), findings)
        self.assertIn(("Indirect DML in Loop", 11, ["saveOne"]), findings)

    def test_detects_transitive_helper_chain(self):
        code = """public class Sample {
    void saveInner(Account account){
        update account;
    }
    void saveOuter(Account account){
        saveInner(account);
    }
    void run(List<Account> accounts){
        for(Account account : accounts){
            saveOuter(account);
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("Indirect DML in Loop", 10, ["saveOuter", "saveInner"]), findings)

    def test_detects_dml_when_assigned_to_database_save_result(self):
        code = """public class Sample {
    void run(List<Account> accounts){
        for(Account account : accounts){
            Database.SaveResult result = Database.update(account, false);
            Database.SaveResult[] bulk = Database.update(accounts, false);
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertIn(("DML in Loop", 4, None), findings)
        self.assertIn(("DML in Loop", 5, None), findings)

    def test_dml_in_loop_not_duplicated_for_nested_loops(self):
        code = """public class Sample {
    void run(List<Account> outer, List<Account> inner){
        for(Account a : outer){
            for(Account b : inner){
                Database.SaveResult sr = Database.update(b, false);
            }
        }
    }
}"""
        findings = [
            f for f in self.get_loop_findings(code)
            if f[0] == "DML in Loop"
        ]
        self.assertEqual(findings, [("DML in Loop", 5, None)])

    def test_nested_loops_with_dml_reports_critical_once(self):
        code = """public class Sample {
    void run(List<Account> outer, List<Account> inner){
        for(Account a : outer){
            for(Account b : inner){
                Database.SaveResult sr = Database.update(b, false);
            }
        }
    }
}"""
        from pattern_matcher import analyze_apex_code as _ana
        nested = [
            v for v in _ana("Sample.cls", code)
            if v.violation_type.value == "Nested Loops with DML/SOQL"
        ]
        self.assertEqual(len(nested), 1, msg=f"Expected single nested-loop violation, got {nested}")
        self.assertEqual(nested[0].line_number, 5)
        self.assertEqual(nested[0].criticality, "Critical")

    def test_avoids_false_positives_for_indexing_or_non_loop_helper_calls(self):
        code = """public class Sample {
    List<Contact> loadContacts(Id accountId){
        return [SELECT Id FROM Contact WHERE AccountId = :accountId];
    }
    void run(List<Account> accounts){
        Account firstAccount = accounts[0];
        loadContacts(firstAccount.Id);
        for(Integer i = 0; i < accounts.size(); i++){
            Account currentAccount = accounts[i];
        }
    }
}"""
        findings = self.get_loop_findings(code)
        self.assertEqual([], findings)


class SharedSoqlRuleRegressionTests(unittest.TestCase):
    def get_findings(self, code: str):
        return [
            (violation.violation_type.value, violation.line_number)
            for violation in analyze_apex_code("Sample.cls", code, is_trigger=False)
        ]

    def assertHasFinding(self, findings, rule_name, line_number):
        self.assertIn((rule_name, line_number), findings)

    def test_non_loop_soql_rules_keep_reporting_expected_lines(self):
        cases = [
            (
                """public class Sample {
    void run(){
        List<Account> accs = [
            SELECT Id, Name
            FROM Account
        ];
    }
}""",
                "SOQL Without a WHERE Clause or LIMIT Statement",
                3,
            ),
            (
                """public class Sample {
    void run(){
        List<Account> accs = [SELECT Id, Name FROM Account WHERE Name LIKE '%Acme%'];
    }
}""",
                "SOQL with Wildcard Filter",
                3,
            ),
            (
                """public class Sample {
    void run(){
        List<Account> accs = [SELECT Id, Name FROM Account WHERE Name != 'Acme'];
    }
}""",
                "SOQL with Negative Expressions",
                3,
            ),
            (
                """public class Sample {
    void run(){
        List<Account> accs = [SELECT Id, Name, Industry FROM Account WHERE Name = 'Acme'];
        for(Account acc : accs){
            System.debug(acc.Name);
        }
    }
}""",
                "SOQL with Unused Fields",
                3,
            ),
            (
                """public class Sample {
    void run(){
        List<Account> accs = [SELECT Id, Name FROM Account];
        for(Account acc : accs){
            if(acc.Name == 'Acme'){
                System.debug(acc.Id);
            }
        }
    }
}""",
                "SOQL with Apex Filter",
                3,
            ),
            (
                """public class Sample {
    void run(String name){
        List<SObject> rows = Database.query('SELECT Id FROM Account WHERE Name = \\'" + name + "\\'');
    }
}""",
                "SOQL Injection Risk",
                3,
            ),
        ]

        for code, rule_name, line_number in cases:
            with self.subTest(rule=rule_name):
                findings = self.get_findings(code)
                self.assertHasFinding(findings, rule_name, line_number)

    def test_soql_for_loop_remains_allowed_for_loop_rule(self):
        code = """public class Sample {
    void run(){
        for(Account account : [SELECT Id FROM Account]){
            System.debug(account.Id);
        }
    }
}"""
        findings = self.get_findings(code)
        loop_rules = {
            "SOQL in Loop",
            "DML in Loop",
            "Indirect SOQL in Loop",
            "Indirect DML in Loop",
        }
        self.assertFalse(any(rule_name in loop_rules for rule_name, _ in findings))


if __name__ == "__main__":
    unittest.main()
